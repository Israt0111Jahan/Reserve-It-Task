﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Work_01_Api.Models;

namespace Work_01_Api.Controllers
{
    public class CrudApiController : ApiController
    {
        CustomerDBEntities db = new CustomerDBEntities();
        [System.Web.Http.HttpGet]
        public IHttpActionResult GetStudents()
        {
            List<Student> list = db.Students.ToList();
            return Ok(list);
        }
        [System.Web.Http.HttpPost]
        public IHttpActionResult StuInsert(Student s)
        {
            db.Students.Add(s);
            db.SaveChanges();
            return Ok();
        }
    }
}
